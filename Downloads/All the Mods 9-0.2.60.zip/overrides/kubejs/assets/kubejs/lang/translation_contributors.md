# Translation Contributors
(bullet list, <name(discord/github)> github/other link)

English, AllTheMods Team and quest devs/contributors,
- AlfredGG
- Jonh09
- ToshibaMicrowave


Japanese,
- flll (https://github.com/flll)

French, (partial, needs updating)
- FabLeKebab (https://github.com/FabLeKebab)

Spanish,
- radzratz (https://github.com/RadzRatz)
- 102389 (https://github.com/102389)
- Arivio (https://github.com/Arivios)

Norwegian (BokMål)
- Permest (https://github.com/Permest)

Korean (packmenu buttons)
- ArcTrooper (https://github.com/ArcTrooper210)

Portuguese 
- oRuiva (https://github.com/oRuiva)

